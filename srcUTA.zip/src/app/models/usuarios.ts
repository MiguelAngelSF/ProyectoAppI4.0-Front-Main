export class UsuarioModel {
    _id?: string;
    estado: string;
    nombre:string;
    email: string;
    password: string;
    edad: number;
    tipoUsuario: string;
    genero: string

}