export class DatospModel {
    telefono: string;
    rfc: string;
    imagen: string;
  }