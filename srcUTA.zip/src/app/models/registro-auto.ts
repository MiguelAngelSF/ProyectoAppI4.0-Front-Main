export class RegistroAutoModel{
    _id?:string;
    idDriver:string;
    propietario: string;
    placas:string;
    modelo:string;
    anio:string;
}