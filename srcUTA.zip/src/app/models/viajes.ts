export class ViajeModel {
    _id?: string;
    destino: string;
    actual:string;
    email: string;
    pago: string;
}