export class CalificacionModel {
    _id?: string;
    nombre: string;
    calificacion: string;
}