export class AlertapModel {
    _id?: string;
    descripcion: string;
}