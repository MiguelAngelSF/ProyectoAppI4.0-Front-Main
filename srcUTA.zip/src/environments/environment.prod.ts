export const environment = {
  production: true,
  mapsKeyApi : "AIzaSyDrnlnJ5tyADRyC43bSpZb2EojvymL7rXo"
};